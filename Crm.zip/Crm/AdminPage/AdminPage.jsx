/* eslint-disable no-unused-vars */
import React, { useContext } from 'react'
import Css from "./AdminPage.module.css"
import SideNav from '../SideNav/SideNav'
import Datacontext from '../../Context/Datacontext/DataContext'
import UserData from '../UserData/UserData'

function AdminPage() {

  const a = useContext(Datacontext)
  return (
    <>
      <div className={Css.AdminPageWrapper}>
        <h1>Admin Dashborad {a.userType.name}</h1>
        <div className={Css.ComprnentWrapper}>
        <SideNav/>
        <UserData/>
        </div>
       
      </div>
    </>
  )
}

export default AdminPage