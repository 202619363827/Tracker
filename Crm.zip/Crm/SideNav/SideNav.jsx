import React from 'react'
import Css from "./SideNav.module.css"
import img1 from "../../assets/react.svg"

function SideNav() {
    return (
        <>
            <div className={Css.SidenavWrapper}>
                <div className={Css.Profile}>
                    <div className={Css.PfImg}>
                        <img src={img1} />
                    </div>
                    <div className={Css.PfName}>
                        <h3>Rohan ukey</h3>
                    </div>
                </div>
                <div className={Css.SideMenu}>
                    <h3>SideMenu</h3>
                    <ul>
                        <li><img src={img1} /><span>Dashboard</span></li>
                        <li><img src={img1} /><span>Employees</span></li>
                        <li><img src={img1} /><span>Analytics</span></li>
                        <li><img src={img1} /><span>Client</span></li>
                    </ul>
                </div>
            </div>
        </>
    )
}

export default SideNav