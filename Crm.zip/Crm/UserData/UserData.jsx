import React from 'react'
import Css from "./UserData.module.css"

function UserData() {

   

  return (
    <>
    <div className={Css.EmployeeWrapper}>
    
    </div>
    </>
  )
}

export default UserData